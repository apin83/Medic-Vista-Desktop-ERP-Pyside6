from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
import xml.parsers.expat

if not os.environ.get("DISPLAY") and sys.platform.startswith("linux"):
    # Permit import and smoke checks on headless build servers. Desktop users
    # with a display keep the native Qt platform selected by their OS.
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")


from app.qt_compat import ensure_application, install_legacy_imports


def main() -> int:
    qt_app = ensure_application()
    qt_app.setApplicationName("MedicVista Retailer")
    qt_app.setOrganizationName("MedicVista")

    install_legacy_imports()
    sync_dir = Path(__file__).resolve().parent / "retailer_sync"
    if str(sync_dir) not in sys.path:
        sys.path.insert(0, str(sync_dir))

    log_dir = Path(__file__).resolve().parent / "logs"
    log_dir.mkdir(exist_ok=True)
    logging.basicConfig(
        filename=log_dir / "app.log",
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    try:
        from app.application import RetailerDesktopApp

        window = RetailerDesktopApp()
        window.show()
        return qt_app.exec()
    except Exception as exc:
        logging.exception("MedicVista Retailer could not start.")
        from PySide6 import QtWidgets

        QtWidgets.QMessageBox.critical(
            None,
            "MedicVista Retailer",
            f"The application could not start:\n{exc}",
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
