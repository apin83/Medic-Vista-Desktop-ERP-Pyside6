"""PySide6-backed bridge for the legacy Tk-style screen API.

All widgets created by this module are Qt widgets.  The bridge keeps the
existing screen behavior available while allowing the UI to move to PySide6
incrementally, without importing or initializing Tcl/Tk.
"""

from __future__ import annotations

import sys
import types
from dataclasses import dataclass
from typing import Any, Callable

from PySide6 import QtCore, QtGui, QtWidgets


_APP = QtWidgets.QApplication.instance()


def ensure_application() -> QtWidgets.QApplication:
    global _APP
    _APP = QtWidgets.QApplication.instance() or QtWidgets.QApplication(sys.argv[:1])
    _APP.setStyle("Fusion")
    return _APP


def _font(value: Any) -> QtGui.QFont | None:
    if isinstance(value, QtGui.QFont):
        return value
    if not isinstance(value, (tuple, list)) or not value:
        return None
    family = str(value[0])
    size = int(value[1]) if len(value) > 1 and str(value[1]).isdigit() else 10
    result = QtGui.QFont(family, size)
    if any(str(part).lower() in {"bold", "semibold"} for part in value[2:]):
        result.setBold(True)
    if any(str(part).lower() == "italic" for part in value[2:]):
        result.setItalic(True)
    return result


def _qt_alignment(value: Any) -> QtCore.Qt.AlignmentFlag:
    text = str(value or "").lower()
    align = QtCore.Qt.AlignmentFlag(0)
    if "w" in text or "left" in text:
        align |= QtCore.Qt.AlignmentFlag.AlignLeft
    elif "e" in text or "right" in text:
        align |= QtCore.Qt.AlignmentFlag.AlignRight
    else:
        align |= QtCore.Qt.AlignmentFlag.AlignHCenter
    if "n" in text or "top" in text:
        align |= QtCore.Qt.AlignmentFlag.AlignTop
    elif "s" in text or "bottom" in text:
        align |= QtCore.Qt.AlignmentFlag.AlignBottom
    else:
        align |= QtCore.Qt.AlignmentFlag.AlignVCenter
    return align


@dataclass
class _LayoutEntry:
    widget: QtWidgets.QWidget
    manager: str
    options: dict[str, Any]
    item: QtWidgets.QLayoutItem | None = None


class LegacyLayout(QtWidgets.QLayout):
    """Small geometry-manager adapter supporting pack, grid, and place."""

    def __init__(self, parent: QtWidgets.QWidget):
        super().__init__(parent)
        self.entries: list[_LayoutEntry] = []
        self.setContentsMargins(0, 0, 0, 0)
        self.setSpacing(0)

    def addItem(self, item: QtWidgets.QLayoutItem) -> None:
        widget = item.widget()
        if widget is not None:
            self.entries.append(_LayoutEntry(widget, "pack", {}, item))

    def add_legacy(self, widget: QtWidgets.QWidget, manager: str, options: dict[str, Any]) -> None:
        for entry in self.entries:
            if entry.widget is widget:
                entry.manager = manager
                entry.options = dict(options)
                self.invalidate()
                return
        self.entries.append(_LayoutEntry(widget, manager, dict(options), QtWidgets.QWidgetItem(widget)))
        self.addChildWidget(widget)
        self.invalidate()

    def count(self) -> int:
        return len(self.entries)

    def itemAt(self, index: int) -> QtWidgets.QLayoutItem | None:
        if 0 <= index < len(self.entries):
            return self.entries[index].item
        return None

    def takeAt(self, index: int) -> QtWidgets.QLayoutItem | None:
        if 0 <= index < len(self.entries):
            entry = self.entries.pop(index)
            self.invalidate()
            return entry.item
        return None

    def remove_widget(self, widget: QtWidgets.QWidget) -> None:
        self.entries = [entry for entry in self.entries if entry.widget is not widget]
        self.invalidate()

    def sizeHint(self) -> QtCore.QSize:
        width = height = 0
        for entry in self.entries:
            if not entry.widget.isVisible():
                continue
            hint = entry.widget.sizeHint()
            width = max(width, hint.width())
            height += hint.height()
        return QtCore.QSize(width + 20, height + 20)

    def minimumSize(self) -> QtCore.QSize:
        return QtCore.QSize(40, 30)

    @staticmethod
    def _padding(options: dict[str, Any]) -> tuple[int, int, int, int]:
        value = options.get("padx", 0)
        if isinstance(value, (tuple, list)):
            px1, px2 = (int(value[0]), int(value[-1]))
        else:
            px1 = px2 = int(value or 0)
        value = options.get("pady", 0)
        if isinstance(value, (tuple, list)):
            py1, py2 = (int(value[0]), int(value[-1]))
        else:
            py1 = py2 = int(value or 0)
        return px1, py1, px2, py2

    @staticmethod
    def _hint(widget: QtWidgets.QWidget, options: dict[str, Any]) -> QtCore.QSize:
        size = widget.sizeHint().expandedTo(widget.minimumSizeHint())
        if options.get("width") is not None:
            width = int(options["width"])
            size.setWidth(max(1, width if width > 40 else width * 8))
        if options.get("height") is not None:
            height = int(options["height"])
            size.setHeight(max(1, height if height > 40 else height * 2))
        return size

    def setGeometry(self, rect: QtCore.QRect) -> None:
        super().setGeometry(rect)
        area = QtCore.QRect(rect)
        margins = self.contentsMargins()
        area.adjust(margins.left(), margins.top(), -margins.right(), -margins.bottom())

        visible = [entry for entry in self.entries if not entry.widget.isHidden()]
        for entry in visible:
            if entry.manager == "place":
                self._place(entry, area)

        grid_entries = [entry for entry in visible if entry.manager == "grid"]
        if grid_entries:
            self._grid(grid_entries, area)

        pack_entries = [entry for entry in visible if entry.manager == "pack"]
        if pack_entries:
            self._pack(pack_entries, area)

    def _place(self, entry: _LayoutEntry, area: QtCore.QRect) -> None:
        options = entry.options
        widget = entry.widget
        hint = self._hint(widget, options)
        width = int(options.get("width", hint.width()))
        height = int(options.get("height", hint.height()))
        x = int(options.get("x", 0)) + int(float(options.get("relx", 0)) * area.width())
        y = int(options.get("y", 0)) + int(float(options.get("rely", 0)) * area.height())
        anchor = str(options.get("anchor", "nw")).lower()
        if "e" in anchor:
            x -= width
        elif anchor in {"center", "c"}:
            x -= width // 2
        if "s" in anchor:
            y -= height
        elif anchor in {"center", "c"}:
            y -= height // 2
        widget.setGeometry(x, y, max(1, width), max(1, height))

    def _pack(self, entries: list[_LayoutEntry], area: QtCore.QRect) -> None:
        remaining = QtCore.QRect(area)
        expanding = [entry for entry in entries if entry.options.get("expand")]
        for index, entry in enumerate(entries):
            widget, options = entry.widget, entry.options
            if remaining.width() <= 0 or remaining.height() <= 0:
                break
            side = str(options.get("side", "top")).lower()
            fill = str(options.get("fill", "")).lower()
            pad_left, pad_top, pad_right, pad_bottom = self._padding(options)
            hint = self._hint(widget, options)
            rest = len([item for item in entries[index:] if item.options.get("expand")]) or 1

            if side in {"left", "right"}:
                width = remaining.width() // rest if options.get("expand") else hint.width()
                width = min(remaining.width(), max(1, width))
                height = remaining.height() if fill in {"y", "both"} or options.get("expand") else min(remaining.height(), hint.height())
                x = remaining.left() if side == "left" else remaining.right() - width + 1
                y = remaining.top()
                box = QtCore.QRect(x, y, width, height)
                if side == "left":
                    remaining.setLeft(x + width)
                else:
                    remaining.setRight(x - 1)
            else:
                height = remaining.height() // rest if options.get("expand") else hint.height()
                height = min(remaining.height(), max(1, height))
                width = remaining.width() if fill in {"x", "both"} or options.get("expand") else min(remaining.width(), hint.width())
                x = remaining.left()
                y = remaining.top() if side == "top" else remaining.bottom() - height + 1
                box = QtCore.QRect(x, y, width, height)
                if side == "top":
                    remaining.setTop(y + height)
                else:
                    remaining.setBottom(y - 1)
            box.adjust(pad_left, pad_top, -pad_right, -pad_bottom)
            widget.setGeometry(box)

    def _grid(self, entries: list[_LayoutEntry], area: QtCore.QRect) -> None:
        rows: dict[int, int] = {}
        columns: dict[int, int] = {}
        for entry in entries:
            row = int(entry.options.get("row", 0))
            col = int(entry.options.get("column", 0))
            hint = self._hint(entry.widget, entry.options)
            rows[row] = max(rows.get(row, 0), hint.height())
            columns[col] = max(columns.get(col, 0), hint.width())
        if not rows or not columns:
            return
        parent = self.parentWidget()
        row_weights = getattr(parent, "_legacy_row_weights", {}) or {}
        col_weights = getattr(parent, "_legacy_col_weights", {}) or {}
        extra_w = max(0, area.width() - sum(columns.values()))
        extra_h = max(0, area.height() - sum(rows.values()))
        total_col_weight = sum(col_weights.get(c, 0) for c in columns) or 1
        total_row_weight = sum(row_weights.get(r, 0) for r in rows) or 1
        col_x: dict[int, int] = {}
        row_y: dict[int, int] = {}
        x = area.x()
        for col, width in sorted(columns.items()):
            col_x[col] = x
            x += width + int(extra_w * col_weights.get(col, 0) / total_col_weight)
        y = area.y()
        for row, height in sorted(rows.items()):
            row_y[row] = y
            y += height + int(extra_h * row_weights.get(row, 0) / total_row_weight)
        for entry in entries:
            options = entry.options
            row, col = int(options.get("row", 0)), int(options.get("column", 0))
            width, height = columns.get(col, 1), rows.get(row, 1)
            rowspan = int(options.get("rowspan", 1))
            colspan = int(options.get("columnspan", 1))
            if colspan > 1:
                width = sum(columns.get(c, 0) for c in range(col, col + colspan))
            if rowspan > 1:
                height = sum(rows.get(r, 0) for r in range(row, row + rowspan))
            left, top, right, bottom = self._padding(options)
            box = QtCore.QRect(col_x.get(col, area.x()), row_y.get(row, area.y()), width, height)
            box.adjust(left, top, -right, -bottom)
            sticky = str(options.get("sticky", "")).lower()
            if not sticky:
                hint = self._hint(entry.widget, options)
                box.setSize(hint.boundedTo(box.size()))
                box.moveCenter(QtCore.QRect(col_x.get(col, area.x()), row_y.get(row, area.y()), width, height).center())
            entry.widget.setGeometry(box)


class LegacyMixin:
    def _legacy_init(self, parent: QtWidgets.QWidget | None, options: dict[str, Any]) -> None:
        self._legacy_options: dict[str, Any] = {}
        self._legacy_bindings: dict[str, list[Callable]] = {}
        self._legacy_timers: dict[str, QtCore.QTimer] = {}
        self._legacy_value = ""
        self._legacy_tags: dict[str, dict[str, Any]] = {}
        self._legacy_grid_weights: dict[str, dict[int, int]] = {"row": {}, "column": {}}
        self._legacy_apply(options)
        if parent is not None and isinstance(parent, QtWidgets.QWidget) and parent.layout() is None:
            parent.setLayout(LegacyLayout(parent))
        self.installEventFilter(_LegacyEventFilter(self))

    def _legacy_apply(self, options: dict[str, Any]) -> None:
        for key, value in options.items():
            if key in {"bg", "background", "fg", "foreground"}:
                self._set_color(key, value)
            elif key == "font":
                font = _font(value)
                if font:
                    self.setFont(font)
            elif key == "text":
                self._set_text(value)
            elif key == "textvariable":
                self._set_variable(value)
            elif key in {"width", "height"} and hasattr(self, "setMinimum" + key.capitalize()):
                setter = getattr(self, "setMinimum" + key.capitalize())
                numeric = int(value)
                setter(numeric if numeric > 40 else numeric * (8 if key == "width" else 2))
            elif key == "state":
                self.setEnabled(str(value).lower() not in {"disabled", "readonly"})
                if str(value).lower() == "readonly" and hasattr(self, "setReadOnly"):
                    self.setReadOnly(True)
            elif key == "show" and isinstance(self, QtWidgets.QLineEdit):
                self.setEchoMode(QtWidgets.QLineEdit.EchoMode.Password if value else QtWidgets.QLineEdit.EchoMode.Normal)
            elif key == "values" and isinstance(self, QtWidgets.QComboBox):
                self.clear()
                self.addItems([str(item) for item in value])
            elif key == "command":
                self._legacy_set_command(value)
            elif key == "justify" and isinstance(self, QtWidgets.QLabel):
                self.setAlignment(_qt_alignment(value))
            elif key == "anchor" and isinstance(self, QtWidgets.QLabel):
                self.setAlignment(_qt_alignment(value))
            elif key == "wraplength" and isinstance(self, QtWidgets.QLabel):
                self.setWordWrap(True)
            elif key == "cursor":
                if value == "hand2":
                    self.setCursor(QtCore.Qt.CursorShape.PointingHandCursor)
            elif key == "relief" and value == "flat":
                self.setFrameShape(QtWidgets.QFrame.Shape.NoFrame) if isinstance(self, QtWidgets.QFrame) else None
            elif key == "padding" and isinstance(self, QtWidgets.QWidget):
                self._apply_padding(value)
            elif key == "placeholder" and isinstance(self, QtWidgets.QLineEdit):
                self.setPlaceholderText(str(value))
            elif key == "insertbackground":
                self._legacy_options[key] = value
            else:
                self._legacy_options[key] = value
        self.updateGeometry()

    def _set_color(self, key: str, value: Any) -> None:
        if value is None:
            return
        color = str(value)
        if key in {"fg", "foreground"}:
            palette = self.palette()
            palette.setColor(QtGui.QPalette.ColorRole.WindowText, QtGui.QColor(color))
            palette.setColor(QtGui.QPalette.ColorRole.Text, QtGui.QColor(color))
            palette.setColor(QtGui.QPalette.ColorRole.ButtonText, QtGui.QColor(color))
            self.setPalette(palette)
            if isinstance(self, (QtWidgets.QLabel, QtWidgets.QPushButton)):
                self.setStyleSheet(f"color: {color};")
        else:
            palette = self.palette()
            palette.setColor(QtGui.QPalette.ColorRole.Window, QtGui.QColor(color))
            palette.setColor(QtGui.QPalette.ColorRole.Base, QtGui.QColor(color))
            palette.setColor(QtGui.QPalette.ColorRole.Button, QtGui.QColor(color))
            self.setPalette(palette)
            self.setAutoFillBackground(True)
            if isinstance(self, (QtWidgets.QFrame, QtWidgets.QLabel, QtWidgets.QPushButton)):
                self.setStyleSheet(f"background-color: {color};")

    def _set_text(self, value: Any) -> None:
        text = "" if value is None else str(value)
        if isinstance(self, (QtWidgets.QLabel, QtWidgets.QPushButton, QtWidgets.QCheckBox, QtWidgets.QRadioButton)):
            self.setText(text)
        elif isinstance(self, QtWidgets.QLineEdit):
            self.setText(text)
        self._legacy_value = text

    def _set_variable(self, variable: "LegacyVariable") -> None:
        self._legacy_variable = variable
        if isinstance(self, QtWidgets.QLineEdit):
            self.setText(str(variable.get()))
            self.textChanged.connect(lambda value: variable.set(value, emit=False))
            variable.subscribe(lambda value: self.setText(str(value)) if self.text() != str(value) else None)
        elif isinstance(self, (QtWidgets.QLabel, QtWidgets.QPushButton)):
            self.setText(str(variable.get()))
            variable.subscribe(lambda value: self.setText(str(value)))
        elif isinstance(self, (QtWidgets.QCheckBox, QtWidgets.QRadioButton)):
            self.setChecked(bool(variable.get()))
            self.toggled.connect(lambda value: variable.set(value, emit=False))
            variable.subscribe(lambda value: self.setChecked(bool(value)) if self.isChecked() != bool(value) else None)

    def _set_command(self, command: Callable | None) -> None:
        if command is None:
            return
        if isinstance(self, QtWidgets.QAbstractButton):
            old_slot = getattr(self, "_legacy_command_slot", None)
            if old_slot is not None:
                try:
                    self.clicked.disconnect(old_slot)
                except (RuntimeError, TypeError):
                    pass
            slot = lambda *_: command()
            self._legacy_command_slot = slot
            self._legacy_command = command
            self.clicked.connect(slot)
        elif isinstance(self, QtWidgets.QComboBox):
            old_slot = getattr(self, "_legacy_command_slot", None)
            if old_slot is not None:
                try:
                    self.activated.disconnect(old_slot)
                except (RuntimeError, TypeError):
                    pass
            slot = lambda *_: command()
            self._legacy_command_slot = slot
            self._legacy_command = command
            self.activated.connect(slot)

    def _legacy_set_command(self, command: Callable | None) -> None:
        self._set_command(command)

    def _apply_padding(self, value: Any) -> None:
        if not isinstance(self, QtWidgets.QWidget):
            return
        if isinstance(value, (tuple, list)):
            vals = [int(v) for v in value]
            if len(vals) == 2:
                left = right = vals[0]
                top = bottom = vals[1]
            elif len(vals) >= 4:
                left, top, right, bottom = vals[:4]
            else:
                left = top = right = bottom = 0
        else:
            left = top = right = bottom = int(value or 0)
        self.setContentsMargins(left, top, right, bottom)

    def configure(self, **options: Any) -> None:
        self._legacy_options.update(options)
        self._legacy_apply(options)

    config = configure

    def cget(self, key: str) -> Any:
        if key == "text" and hasattr(self, "text"):
            return self.text()
        if key in {"bg", "background"}:
            return self.palette().color(QtGui.QPalette.ColorRole.Window).name()
        if key in {"fg", "foreground"}:
            return self.palette().color(QtGui.QPalette.ColorRole.WindowText).name()
        if key == "state":
            return "normal" if self.isEnabled() else "disabled"
        return self._legacy_options.get(key)

    def __getitem__(self, key: str) -> Any:
        return self.cget(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.configure(**{key: value})

    def pack(self, **options: Any) -> None:
        _add_to_layout(self, "pack", options)
        self.show()

    def grid(self, **options: Any) -> None:
        _add_to_layout(self, "grid", options)
        self.show()

    def place(self, **options: Any) -> None:
        _add_to_layout(self, "place", options)
        self.show()

    def pack_forget(self) -> None:
        self._legacy_forget()

    grid_forget = pack_forget
    place_forget = pack_forget
    grid_remove = pack_forget

    def _legacy_forget(self) -> None:
        parent = self.parentWidget()
        if parent and isinstance(parent.layout(), LegacyLayout):
            parent.layout().remove_widget(self)
        self.hide()

    def pack_propagate(self, *_: Any) -> None:
        return None

    grid_propagate = pack_propagate
    place_propagate = pack_propagate

    def rowconfigure(self, index: int, weight: int = 0, **_: Any) -> None:
        self._legacy_grid_weights["row"][int(index)] = int(weight)

    grid_rowconfigure = rowconfigure

    def columnconfigure(self, index: int, weight: int = 0, **_: Any) -> None:
        self._legacy_grid_weights["column"][int(index)] = int(weight)

    grid_columnconfigure = columnconfigure

    def bind(self, sequence: str, callback: Callable, add: Any = None) -> str:
        self._legacy_bindings.setdefault(sequence, [])
        if not add:
            self._legacy_bindings[sequence].clear()
        self._legacy_bindings[sequence].append(callback)
        self._legacy_connect_virtual_event(sequence)
        return f"qt-bind-{id(callback)}"

    def _legacy_connect_virtual_event(self, sequence: str) -> None:
        if sequence == "<<ComboboxSelected>>" and isinstance(self, QtWidgets.QComboBox):
            if not getattr(self, "_legacy_combo_event_connected", False):
                self.currentIndexChanged.connect(lambda *_: self._legacy_emit("<<ComboboxSelected>>"))
                self._legacy_combo_event_connected = True
        elif sequence == "<<TreeviewSelect>>" and isinstance(self, QtWidgets.QTreeWidget):
            if not getattr(self, "_legacy_tree_event_connected", False):
                self.itemSelectionChanged.connect(lambda: self._legacy_emit("<<TreeviewSelect>>"))
                self._legacy_tree_event_connected = True
        elif sequence == "<<ListboxSelect>>" and isinstance(self, QtWidgets.QListWidget):
            if not getattr(self, "_legacy_list_event_connected", False):
                self.itemSelectionChanged.connect(lambda: self._legacy_emit("<<ListboxSelect>>"))
                self._legacy_list_event_connected = True

    def _legacy_emit(self, sequence: str, event: Any = None) -> None:
        for callback in self._legacy_bindings.get(sequence, []):
            try:
                callback(event or LegacyEvent(self))
            except TypeError:
                callback()

    def bind_all(self, sequence: str, callback: Callable, add: Any = None) -> None:
        key = _sequence_to_key(sequence)
        if key:
            shortcut = QtGui.QShortcut(key, self.window())
            shortcut.activated.connect(lambda: callback(LegacyEvent(self)))
            if not hasattr(self, "_legacy_shortcuts"):
                self._legacy_shortcuts = []
            self._legacy_shortcuts.append(shortcut)

    def focus_set(self) -> None:
        self.setFocus(QtCore.Qt.FocusReason.OtherFocusReason)

    focus_force = focus_set

    def after(self, milliseconds: int, callback: Callable) -> str:
        if QtCore.QThread.currentThread() is not self.thread():
            root = self.window()
            if root is not self and hasattr(root, "after"):
                return root.after(milliseconds, callback)
        timer = QtCore.QTimer(self)
        timer.setSingleShot(True)
        timer.timeout.connect(callback)
        timer.start(max(0, int(milliseconds)))
        token = str(id(timer))
        self._legacy_timers[token] = timer
        timer.timeout.connect(lambda: self._legacy_timers.pop(token, None))
        return token

    def after_cancel(self, token: str) -> None:
        timer = self._legacy_timers.pop(str(token), None)
        if timer:
            timer.stop()
            timer.deleteLater()

    def destroy(self) -> None:
        if isinstance(self, QtWidgets.QDialog):
            self.close()
        parent = self.parentWidget()
        if parent and isinstance(parent.layout(), LegacyLayout):
            parent.layout().remove_widget(self)
        self.deleteLater()

    def winfo_children(self) -> list[QtWidgets.QWidget]:
        return self.findChildren(QtWidgets.QWidget, options=QtCore.Qt.FindChildOption.FindDirectChildrenOnly)

    @property
    def master(self) -> QtWidgets.QWidget | None:
        return self.parentWidget()

    def winfo_width(self) -> int:
        return self.width()

    def winfo_height(self) -> int:
        return self.height()

    def winfo_x(self) -> int:
        return self.x()

    def winfo_y(self) -> int:
        return self.y()

    def winfo_rootx(self) -> int:
        return self.mapToGlobal(QtCore.QPoint(0, 0)).x()

    def winfo_rooty(self) -> int:
        return self.mapToGlobal(QtCore.QPoint(0, 0)).y()

    def winfo_exists(self) -> bool:
        return True

    def winfo_ismapped(self) -> bool:
        return self.isVisible()

    def winfo_screenwidth(self) -> int:
        return QtGui.QGuiApplication.primaryScreen().availableGeometry().width()

    def winfo_screenheight(self) -> int:
        return QtGui.QGuiApplication.primaryScreen().availableGeometry().height()

    def winfo_toplevel(self) -> QtWidgets.QWidget:
        return self.window()

    def update_idletasks(self) -> None:
        QtWidgets.QApplication.processEvents()

    def update(self) -> None:
        QtWidgets.QApplication.processEvents()

    def title(self, value: str | None = None) -> str | None:
        if value is None:
            return self.window().windowTitle()
        self.window().setWindowTitle(str(value))
        return None

    def geometry(self, value: str | None = None) -> str | None:
        target = self.window()
        if value is None:
            geo = target.geometry()
            return f"{geo.width()}x{geo.height()}+{geo.x()}+{geo.y()}"
        if value.startswith("+"):
            pieces = value[1:].split("+")
            if len(pieces) == 2:
                target.move(int(pieces[0]), int(pieces[1]))
            return None
        parts = value.split("+")
        dimensions = parts[0].split("x")
        if len(dimensions) == 2:
            target.resize(int(dimensions[0]), int(dimensions[1]))
        if len(parts) > 1:
            target.move(int(parts[1]), int(parts[2]) if len(parts) > 2 else target.y())
        return None

    def state(self, value: str | None = None) -> str | None:
        target = self.window()
        if value is None:
            return "zoomed" if target.isMaximized() else "normal"
        if value in {"zoomed", "maximized"}:
            target.showMaximized()
        elif value == "normal":
            target.showNormal()
        elif value == "iconic":
            target.showMinimized()
        return None

    def protocol(self, name: str, callback: Callable) -> None:
        if name == "WM_DELETE_WINDOW":
            self.window()._legacy_close_callback = callback

    def mainloop(self) -> int:
        return ensure_application().exec()

    def lower(self, *_: Any) -> None:
        QtWidgets.QWidget.lower(self)

    def lift(self, *_: Any) -> None:
        QtWidgets.QWidget.raise_(self)

    def selection_get(self) -> str:
        return QtWidgets.QApplication.clipboard().text()

    def clipboard_clear(self) -> None:
        QtWidgets.QApplication.clipboard().clear()

    def clipboard_append(self, value: str) -> None:
        QtWidgets.QApplication.clipboard().setText(str(value))

    def _legacy_add_widget(self, widget: QtWidgets.QWidget, manager: str, options: dict[str, Any]) -> None:
        if self.layout() is None:
            self.setLayout(LegacyLayout(self))
        _add_to_layout(widget, manager, options)


def _add_to_layout(widget: QtWidgets.QWidget, manager: str, options: dict[str, Any]) -> None:
    parent = widget.parentWidget()
    if parent is None:
        return
    layout = parent.layout()
    if layout is None:
        layout = LegacyLayout(parent)
        parent.setLayout(layout)
    if isinstance(layout, LegacyLayout):
        layout.add_legacy(widget, manager, options)
    else:
        layout.addWidget(widget)


class _LegacyEventFilter(QtCore.QObject):
    def __init__(self, widget: LegacyMixin):
        super().__init__(widget)
        self.widget = widget

    def eventFilter(self, watched: QtCore.QObject, event: QtCore.QEvent) -> bool:
        event_type = event.type()
        mapping = {
            QtCore.QEvent.Type.Enter: "<Enter>",
            QtCore.QEvent.Type.Leave: "<Leave>",
            QtCore.QEvent.Type.FocusIn: "<FocusIn>",
            QtCore.QEvent.Type.FocusOut: "<FocusOut>",
            QtCore.QEvent.Type.Resize: "<Configure>",
            QtCore.QEvent.Type.MouseButtonPress: "<Button-1>",
            QtCore.QEvent.Type.MouseButtonRelease: "<ButtonRelease-1>",
            QtCore.QEvent.Type.MouseButtonDblClick: "<Double-1>",
            QtCore.QEvent.Type.KeyPress: "<KeyPress>",
            QtCore.QEvent.Type.KeyRelease: "<KeyRelease>",
            QtCore.QEvent.Type.Wheel: "<MouseWheel>",
        }
        sequence = mapping.get(event_type)
        if sequence:
            legacy_event = LegacyEvent(self.widget, event)
            for callback in list(self.widget._legacy_bindings.get(sequence, [])):
                try:
                    callback(legacy_event)
                except TypeError:
                    callback()
        if event_type == QtCore.QEvent.Type.KeyPress and isinstance(event, QtGui.QKeyEvent):
            key = event.key()
            if key in {QtCore.Qt.Key.Key_Return, QtCore.Qt.Key.Key_Enter}:
                for callback in list(self.widget._legacy_bindings.get("<Return>", [])):
                    callback(LegacyEvent(self.widget, event))
        return False


class LegacyEvent:
    def __init__(self, widget: QtWidgets.QWidget, event: QtCore.QEvent | None = None):
        self.widget = widget
        self.x = self.y = 0
        self.delta = 0
        if isinstance(event, QtGui.QMouseEvent):
            self.x, self.y = int(event.position().x()), int(event.position().y())
        elif isinstance(event, QtGui.QWheelEvent):
            self.delta = event.angleDelta().y()
            self.x, self.y = int(event.position().x()), int(event.position().y())
        elif isinstance(event, QtGui.QKeyEvent):
            self.keysym = QtGui.QKeySequence(event.key()).toString()


class QtFrame(LegacyMixin, QtWidgets.QFrame):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QFrame.__init__(self, parent)
        self._legacy_init(parent, options)


class QtLabel(LegacyMixin, QtWidgets.QLabel):
    def __init__(self, parent: QtWidgets.QWidget | None = None, text: str = "", **options: Any):
        QtWidgets.QLabel.__init__(self, str(text), parent)
        self._legacy_init(parent, options)


class QtButton(LegacyMixin, QtWidgets.QPushButton):
    def __init__(self, parent: QtWidgets.QWidget | None = None, text: str = "", command: Callable | None = None, **options: Any):
        QtWidgets.QPushButton.__init__(self, str(text), parent)
        self._legacy_init(parent, options)
        self._set_command(command or options.get("command"))


class QtEntry(LegacyMixin, QtWidgets.QLineEdit):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QLineEdit.__init__(self, parent)
        self._legacy_init(parent, options)

    def get(self) -> str:
        return self.text()

    def insert(self, index: Any, value: str) -> None:
        if str(index).lower() in {"end", "tk.end"}:
            self.setText(self.text() + str(value))
        else:
            QtWidgets.QLineEdit.insert(self, str(value))

    def delete(self, first: Any, last: Any = None) -> None:
        if last is None:
            self.setText("")
        else:
            self.setText("")

    def selection_range(self, start: int, end: int) -> None:
        self.setSelection(start, end - start)


class QtCheckBox(LegacyMixin, QtWidgets.QCheckBox):
    def __init__(self, parent: QtWidgets.QWidget | None = None, text: str = "", variable: Any = None, command: Callable | None = None, **options: Any):
        QtWidgets.QCheckBox.__init__(self, str(text), parent)
        self._legacy_init(parent, options)
        if variable is not None:
            self._set_variable(variable)
        self._set_command(command or options.get("command"))
        if command:
            self.toggled.connect(lambda *_: command())


class QtRadioButton(LegacyMixin, QtWidgets.QRadioButton):
    def __init__(self, parent: QtWidgets.QWidget | None = None, text: str = "", variable: Any = None, value: Any = None, command: Callable | None = None, **options: Any):
        QtWidgets.QRadioButton.__init__(self, str(text), parent)
        self._legacy_init(parent, options)
        self._radio_value = value
        if variable is not None:
            variable.subscribe(lambda current: self.setChecked(current == value))
            self.toggled.connect(lambda checked: variable.set(value if checked else variable.get(), emit=False))
            self.setChecked(variable.get() == value)
        if command:
            self.toggled.connect(lambda *_: command())


class QtText(LegacyMixin, QtWidgets.QPlainTextEdit):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QPlainTextEdit.__init__(self, parent)
        self._legacy_init(parent, options)
        self._legacy_tags: dict[str, dict[str, Any]] = {}

    def insert(self, index: Any, value: str, *_: Any) -> None:
        if str(index).lower() in {"end", "tk.end"}:
            self.appendPlainText(str(value).rstrip("\n"))
        else:
            self.insertPlainText(str(value))

    def delete(self, start: Any, end: Any = None) -> None:
        if start in {"1.0", "0.0", "1"} or end in {"end", "tk.end"}:
            self.clear()
        else:
            self.clear()

    def get(self, *_: Any) -> str:
        return self.toPlainText()

    def tag_configure(self, tag: str, **options: Any) -> None:
        self._legacy_tags[tag] = options

    def yview(self, *_: Any) -> tuple[float, float]:
        bar = self.verticalScrollBar()
        total = max(1, bar.maximum() + bar.pageStep())
        return bar.value() / total, (bar.value() + bar.pageStep()) / total


class QtListbox(LegacyMixin, QtWidgets.QListWidget):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QListWidget.__init__(self, parent)
        self._legacy_init(parent, options)

    def insert(self, index: Any, *items: Any) -> None:
        if str(index).lower() in {"end", "tk.end"}:
            self.addItems([str(item) for item in items])
        else:
            for offset, item in enumerate(items):
                self.insertItem(int(index) + offset, str(item))

    def delete(self, first: Any, last: Any = None) -> None:
        start = int(first)
        end = self.count() - 1 if last in {"end", "tk.end"} else int(last or first)
        for row in range(end, start - 1, -1):
            item = self.takeItem(row)
            del item

    def get(self, first: Any, last: Any = None) -> Any:
        if last in {"end", "tk.end"}:
            return tuple(self.item(index).text() for index in range(int(first), self.count()))
        item = self.item(int(first))
        return item.text() if item else ""

    def curselection(self) -> tuple[int, ...]:
        return tuple(self.row(item) for item in self.selectedItems())


class QtComboBox(LegacyMixin, QtWidgets.QComboBox):
    def __init__(self, parent: QtWidgets.QWidget | None = None, textvariable: Any = None, values: Any = None, **options: Any):
        QtWidgets.QComboBox.__init__(self, parent)
        self._legacy_init(parent, options)
        if values is not None:
            self.addItems([str(value) for value in values])
        if textvariable is not None:
            self.setCurrentText(str(textvariable.get()))
            self.currentTextChanged.connect(lambda text: textvariable.set(text, emit=False))
            textvariable.subscribe(lambda text: self.setCurrentText(str(text)))
        if str(options.get("state", "")).lower() == "readonly":
            self.setEditable(False)

    def get(self) -> str:
        return self.currentText()

    def set(self, text: str) -> None:
        self.setCurrentText(str(text))

    def current(self, index: int | None = None) -> int:
        if index is None:
            return self.currentIndex()
        self.setCurrentIndex(int(index))
        return self.currentIndex()

    def configure(self, **options: Any) -> None:
        if "values" in options:
            self.clear()
            self.addItems([str(value) for value in options.pop("values")])
        super().configure(**options)

    config = configure


class QtTreeview(LegacyMixin, QtWidgets.QTreeWidget):
    def __init__(self, parent: QtWidgets.QWidget | None = None, columns: Any = (), **options: Any):
        QtWidgets.QTreeWidget.__init__(self, parent)
        self._legacy_init(parent, options)
        self.setRootIsDecorated(False)
        self.setAlternatingRowColors(True)
        self.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self._columns = [str(column) for column in columns]
        self._headings: dict[str, str] = {}
        self._iid_map: dict[str, QtWidgets.QTreeWidgetItem] = {}
        self._item_counter = 0
        self.setColumnCount(max(1, len(self._columns)))
        self.setHeaderLabels(self._columns)
        self.itemDoubleClicked.connect(lambda item, _column: self._legacy_emit("<Double-1>", LegacyEvent(self)))

    def heading(self, column: Any, **options: Any) -> Any:
        key = str(column)
        if "text" in options and key != "#0":
            try:
                index = self._columns.index(key)
                labels = [self._headings.get(column_key, column_key) for column_key in self._columns]
                labels[index] = str(options["text"])
                self.setHeaderLabels(labels)
            except Exception:
                pass
            self._headings[key] = str(options["text"])
        return self._headings.get(key, "")

    def column(self, column: Any, **options: Any) -> Any:
        key = str(column)
        index = self._columns.index(key) if key in self._columns else (0 if key == "#0" else -1)
        if index >= 0:
            if options.get("width") is not None:
                self.setColumnWidth(index, int(options["width"]))
            if "stretch" in options:
                self.header().setSectionResizeMode(index, QtWidgets.QHeaderView.ResizeMode.Stretch if options["stretch"] else QtWidgets.QHeaderView.ResizeMode.Interactive)
        return None

    def insert(self, parent: str, index: Any, iid: str | None = None, **options: Any) -> str:
        parent_item = self._iid_map.get(str(parent)) if parent else None
        item = QtWidgets.QTreeWidgetItem()
        values = options.get("values", ())
        for col, value in enumerate(values):
            if col < self.columnCount():
                item.setText(col, str(value if value is not None else ""))
        if options.get("text") and self.columnCount():
            item.setText(0, str(options["text"]))
        tags = options.get("tags", ())
        if isinstance(tags, str):
            tags = (tags,)
        for tag in tags:
            styling = self._legacy_tags.get(tag, {})
            if styling.get("foreground"):
                item.setForeground(0, QtGui.QColor(styling["foreground"]))
            if styling.get("background"):
                item.setBackground(0, QtGui.QColor(styling["background"]))
        if parent_item:
            parent_item.addChild(item)
        else:
            self.addTopLevelItem(item)
        if iid is None:
            self._item_counter += 1
            iid = f"I{self._item_counter:06d}"
        self._iid_map[str(iid)] = item
        item.setData(0, QtCore.Qt.ItemDataRole.UserRole, str(iid))
        return str(iid)

    def item(self, iid: str, option: str | None = None, **options: Any) -> Any:
        item = self._iid_map.get(str(iid))
        if item is None:
            return {} if option is None else None
        if "values" in options:
            values = options["values"]
            for col in range(self.columnCount()):
                item.setText(col, str(values[col]) if col < len(values) else "")
        if "text" in options:
            item.setText(0, str(options["text"]))
        if option == "values":
            return tuple(item.text(col) for col in range(self.columnCount()))
        if option == "text":
            return item.text(0)
        if option == "tags":
            return tuple()
        if option:
            return None
        return {"values": tuple(item.text(col) for col in range(self.columnCount())), "text": item.text(0)}

    def get_children(self, iid: str = "") -> tuple[str, ...]:
        parent = self._iid_map.get(str(iid)) if iid else None
        count = parent.childCount() if parent else self.topLevelItemCount()
        children = [parent.child(index) if parent else self.topLevelItem(index) for index in range(count)]
        return tuple(str(child.data(0, QtCore.Qt.ItemDataRole.UserRole)) for child in children if child is not None)

    def delete(self, *iids: str) -> None:
        for iid in iids:
            item = self._iid_map.pop(str(iid), None)
            if item is None:
                continue
            parent = item.parent()
            if parent:
                parent.removeChild(item)
            else:
                index = self.indexOfTopLevelItem(item)
                if index >= 0:
                    self.takeTopLevelItem(index)

    def selection(self) -> tuple[str, ...]:
        return tuple(str(item.data(0, QtCore.Qt.ItemDataRole.UserRole)) for item in self.selectedItems())

    def selection_set(self, iid: str | list[str] | tuple[str, ...]) -> None:
        self.clearSelection()
        ids = [iid] if isinstance(iid, str) else list(iid)
        for key in ids:
            item = self._iid_map.get(str(key))
            if item:
                item.setSelected(True)

    selection_add = selection_set

    def identify_row(self, y: int) -> str:
        item = self.itemAt(1, int(y))
        return str(item.data(0, QtCore.Qt.ItemDataRole.UserRole)) if item else ""

    def tag_configure(self, tag: str, **options: Any) -> None:
        self._legacy_tags[tag] = options

    def see(self, iid: str) -> None:
        item = self._iid_map.get(str(iid))
        if item:
            self.scrollToItem(item)

    def yview(self, *args: Any) -> Any:
        return self.verticalScrollBar().value() if not args else self.verticalScrollBar().setValue(int(args[-1]))

    def xview(self, *args: Any) -> Any:
        return self.horizontalScrollBar().value() if not args else self.horizontalScrollBar().setValue(int(args[-1]))


class QtScrollbar(LegacyMixin, QtWidgets.QScrollBar):
    def __init__(self, parent: QtWidgets.QWidget | None = None, orient: Any = "vertical", command: Callable | None = None, **options: Any):
        orientation = QtCore.Qt.Orientation.Horizontal if str(orient).lower() == "horizontal" else QtCore.Qt.Orientation.Vertical
        QtWidgets.QScrollBar.__init__(self, orientation, parent)
        self._legacy_init(parent, options)
        if command:
            self.valueChanged.connect(command)

    def set(self, first: Any, last: Any) -> None:
        self.setRange(0, max(0, int(float(last) * 1000)))
        self.setValue(int(float(first) * 1000))


class QtSeparator(LegacyMixin, QtWidgets.QFrame):
    def __init__(self, parent: QtWidgets.QWidget | None = None, orient: Any = "horizontal", **options: Any):
        QtWidgets.QFrame.__init__(self, parent)
        orientation = str(orient).lower()
        self.setFrameShape(QtWidgets.QFrame.Shape.HLine if orientation == "horizontal" else QtWidgets.QFrame.Shape.VLine)
        self._legacy_init(parent, options)


class QtProgressbar(LegacyMixin, QtWidgets.QProgressBar):
    def __init__(self, parent: QtWidgets.QWidget | None = None, mode: str = "determinate", **options: Any):
        QtWidgets.QProgressBar.__init__(self, parent)
        self._legacy_init(parent, options)
        if mode == "indeterminate":
            self.setRange(0, 0)

    def start(self, *_: Any) -> None:
        self.setRange(0, 0)

    def stop(self) -> None:
        self.setRange(0, 100)


class QtSpinbox(LegacyMixin, QtWidgets.QSpinBox):
    def __init__(self, parent: QtWidgets.QWidget | None = None, from_: int = 0, to: int = 99, **options: Any):
        QtWidgets.QSpinBox.__init__(self, parent)
        self.setRange(int(from_), int(to))
        self._legacy_init(parent, options)

    def get(self) -> str:
        return str(self.value())


class QtNotebook(LegacyMixin, QtWidgets.QTabWidget):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QTabWidget.__init__(self, parent)
        self._legacy_init(parent, options)

    def add(self, child: QtWidgets.QWidget, **options: Any) -> None:
        self.addTab(child, str(options.get("text", "")))


class QtCanvas(LegacyMixin, QtWidgets.QGraphicsView):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        self._scene = QtWidgets.QGraphicsScene()
        QtWidgets.QGraphicsView.__init__(self, self._scene, parent)
        self._legacy_items: dict[Any, list[QtWidgets.QGraphicsItem]] = {}
        self._legacy_init(parent, options)
        self.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)
        self.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)

    def create_line(self, x1: float, y1: float, x2: float, y2: float, **options: Any) -> int:
        item = self._scene.addLine(x1, y1, x2, y2, QtGui.QPen(QtGui.QColor(options.get("fill", "#111827")), float(options.get("width", 1))))
        return self._remember_item(item, options.get("tags"))

    def create_oval(self, x1: float, y1: float, x2: float, y2: float, **options: Any) -> int:
        item = self._scene.addEllipse(x1, y1, x2 - x1, y2 - y1, QtGui.QPen(QtGui.QColor(options.get("outline", "#111827"))), QtGui.QBrush(QtGui.QColor(options.get("fill", "transparent"))))
        return self._remember_item(item, options.get("tags"))

    def create_text(self, x: float, y: float, **options: Any) -> int:
        item = self._scene.addText(str(options.get("text", "")), _font(options.get("font")) or QtGui.QFont())
        item.setDefaultTextColor(QtGui.QColor(options.get("fill", "#111827")))
        item.setPos(x, y)
        return self._remember_item(item, options.get("tags"))

    def create_window(self, x: float | tuple[float, float], y: float | None = None, **options: Any) -> int:
        if isinstance(x, (tuple, list)):
            x, y = float(x[0]), float(x[1])
        if y is None:
            y = 0
        widget = options.get("window")
        if widget is not None:
            parent = widget.parentWidget()
            if parent is not None and parent.layout() is not None:
                parent.layout().removeWidget(widget)
            widget.setParent(None)
            item = self._scene.addWidget(widget)
            item.setPos(x, y)
            return self._remember_item(item, options.get("tags"))
        return 0

    def _remember_item(self, item: QtWidgets.QGraphicsItem, tags: Any) -> int:
        item_id = id(item)
        keys = list(tags) if isinstance(tags, (list, tuple)) else [tags]
        self._legacy_items[item_id] = [item]
        for key in keys:
            if key:
                self._legacy_items.setdefault(key, []).append(item)
        return item_id

    def delete(self, key: Any) -> None:
        if key == "all":
            self._scene.clear()
            self._legacy_items.clear()
            return
        items = self._legacy_items.pop(key, [])
        if not items:
            items = [item for item in self._scene.items() if item.data(0) == key]
        for item in items:
            self._scene.removeItem(item)

    def coords(self, item_id: int, *coords: float) -> list[float]:
        items = self._legacy_items.get(item_id, [])
        item = items[0] if items else None
        if coords and item is not None:
            item.setPos(float(coords[0]), float(coords[1]))
            if len(coords) >= 4 and isinstance(item, QtWidgets.QGraphicsProxyWidget):
                item.resize(float(coords[2]), float(coords[3]))
        return list(item.sceneBoundingRect().getRect()) if item else []

    def yview_scroll(self, amount: int, what: str = "units") -> None:
        self.verticalScrollBar().setValue(self.verticalScrollBar().value() + int(amount) * (20 if what == "units" else 100))

    def yview(self, *args: Any) -> Any:
        if args:
            self.verticalScrollBar().setValue(int(float(args[-1]) * self.verticalScrollBar().maximum()))
        return self.verticalScrollBar().value()

    def xview(self, *args: Any) -> Any:
        if args:
            self.horizontalScrollBar().setValue(int(float(args[-1]) * self.horizontalScrollBar().maximum()))
        return self.horizontalScrollBar().value()

    def tag_configure(self, *_: Any, **__: Any) -> None:
        return None

    def tag_bind(self, *_: Any, **__: Any) -> None:
        return None


class QtMenu(QtWidgets.QMenu):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **_: Any):
        super().__init__(parent)

    def add_command(self, label: str, command: Callable | None = None, **options: Any) -> None:
        action = self.addAction(label)
        if command:
            action.triggered.connect(command)

    def add_separator(self) -> None:
        self.addSeparator()

    def add_cascade(self, label: str, menu: Any, **_: Any) -> None:
        self.addMenu(menu)

    def tk_popup(self, x: int, y: int) -> None:
        self.exec(QtGui.QCursor.pos() if x < 0 or y < 0 else QtCore.QPoint(x, y))


class QtDialog(LegacyMixin, QtWidgets.QDialog):
    def __init__(self, parent: QtWidgets.QWidget | None = None, **options: Any):
        QtWidgets.QDialog.__init__(self, parent)
        self._legacy_init(parent, options)

    def wait_window(self, *_: Any) -> int:
        return self.exec()

    def grab_set(self) -> None:
        self.setModal(True)
        self.show()

    def transient(self, parent: QtWidgets.QWidget | None = None) -> None:
        if parent:
            self.setParent(parent, self.windowFlags() | QtCore.Qt.WindowType.Dialog)


class LegacyVariable:
    def __init__(self, value: Any = "", **_: Any):
        self._value = value
        self._callbacks: list[Callable[[Any], None]] = []

    def get(self) -> Any:
        return self._value

    def set(self, value: Any, emit: bool = True) -> None:
        self._value = value
        if emit:
            for callback in tuple(self._callbacks):
                callback(value)

    def subscribe(self, callback: Callable[[Any], None]) -> None:
        self._callbacks.append(callback)

    def trace_add(self, _mode: str, callback: Callable, *_: Any) -> str:
        self.subscribe(lambda _value: callback("", "", "write"))
        return str(id(callback))

    def trace(self, _mode: str, callback: Callable, *_: Any) -> str:
        return self.trace_add(_mode, callback)


class QtStyle:
    def __init__(self, *_: Any, **__: Any):
        self._configured: dict[str, dict[str, Any]] = {}

    def configure(self, name: str, **options: Any) -> None:
        self._configured[name] = options

    def map(self, *_: Any, **__: Any) -> None:
        return None

    def layout(self, name: str, specification: Any = None) -> Any:
        if specification is not None:
            self._configured.setdefault(name, {})["layout"] = specification
        return self._configured.get(name, {}).get("layout", [])

    def theme_use(self, *_: Any, **__: Any) -> str:
        return "Fusion"


class _MessageBox:
    @staticmethod
    def showinfo(title: str, message: str, parent: Any = None, **_: Any) -> None:
        QtWidgets.QMessageBox.information(parent, title, str(message))

    @staticmethod
    def showwarning(title: str, message: str, parent: Any = None, **_: Any) -> None:
        QtWidgets.QMessageBox.warning(parent, title, str(message))

    @staticmethod
    def showerror(title: str, message: str, parent: Any = None, **_: Any) -> None:
        QtWidgets.QMessageBox.critical(parent, title, str(message))

    @staticmethod
    def askyesno(title: str, message: str, parent: Any = None, **_: Any) -> bool:
        return QtWidgets.QMessageBox.question(parent, title, str(message), QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No) == QtWidgets.QMessageBox.StandardButton.Yes

    @staticmethod
    def askokcancel(title: str, message: str, parent: Any = None, **_: Any) -> bool:
        return QtWidgets.QMessageBox.question(parent, title, str(message), QtWidgets.QMessageBox.StandardButton.Ok | QtWidgets.QMessageBox.StandardButton.Cancel) == QtWidgets.QMessageBox.StandardButton.Ok

    @staticmethod
    def askyesnocancel(title: str, message: str, parent: Any = None, **_: Any) -> bool | None:
        result = QtWidgets.QMessageBox.question(parent, title, str(message), QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No | QtWidgets.QMessageBox.StandardButton.Cancel)
        if result == QtWidgets.QMessageBox.StandardButton.Cancel:
            return None
        return result == QtWidgets.QMessageBox.StandardButton.Yes


class _FileDialog:
    @staticmethod
    def asksaveasfilename(parent: Any = None, **options: Any) -> str:
        path, _filter = QtWidgets.QFileDialog.getSaveFileName(parent, options.get("title", "Save file"), options.get("initialfile", ""), options.get("filetypes", "All files (*)"))
        return path

    @staticmethod
    def askopenfilename(parent: Any = None, **options: Any) -> str:
        path, _filter = QtWidgets.QFileDialog.getOpenFileName(parent, options.get("title", "Open file"), options.get("initialdir", ""), options.get("filetypes", "All files (*)"))
        return path

    @staticmethod
    def askdirectory(parent: Any = None, **options: Any) -> str:
        return QtWidgets.QFileDialog.getExistingDirectory(parent, options.get("title", "Select folder"), options.get("initialdir", ""))


class _SimpleDialog:
    @staticmethod
    def askstring(title: str, prompt: str, parent: Any = None, **_: Any) -> str | None:
        value, accepted = QtWidgets.QInputDialog.getText(parent, title, prompt)
        return value if accepted else None

    @staticmethod
    def askinteger(title: str, prompt: str, parent: Any = None, **options: Any) -> int | None:
        value, accepted = QtWidgets.QInputDialog.getInt(parent, title, prompt, options.get("initialvalue", 0), options.get("minvalue", -2147483647), options.get("maxvalue", 2147483647))
        return value if accepted else None

    @staticmethod
    def askfloat(title: str, prompt: str, parent: Any = None, **options: Any) -> float | None:
        value, accepted = QtWidgets.QInputDialog.getDouble(parent, title, prompt, options.get("initialvalue", 0.0))
        return value if accepted else None


def _sequence_to_key(sequence: str) -> QtGui.QKeySequence | None:
    value = sequence.strip("<>").replace("Control", "Ctrl").replace("control", "Ctrl").replace("Shift", "Shift").replace("shift", "Shift")
    value = value.replace("Return", "Enter").replace("Delete", "Del")
    try:
        return QtGui.QKeySequence(value)
    except Exception:
        return None


def install_legacy_imports() -> None:
    """Route legacy GUI imports to PySide6-backed adapters before importing screens."""
    tk_module = types.ModuleType("tkinter")
    ttk_module = types.ModuleType("tkinter.ttk")
    messagebox_module = types.ModuleType("tkinter.messagebox")
    filedialog_module = types.ModuleType("tkinter.filedialog")
    simpledialog_module = types.ModuleType("tkinter.simpledialog")
    constants_module = types.ModuleType("ttkbootstrap.constants")

    names = {
        "Widget": QtWidgets.QWidget,
        "Frame": QtFrame,
        "Label": QtLabel,
        "Button": QtButton,
        "Entry": QtEntry,
        "Checkbutton": QtCheckBox,
        "Radiobutton": QtRadioButton,
        "Text": QtText,
        "Listbox": QtListbox,
        "Canvas": QtCanvas,
        "Toplevel": QtDialog,
        "Tk": QtWidgets.QMainWindow,
        "Menu": QtMenu,
        "Scrollbar": QtScrollbar,
        "StringVar": LegacyVariable,
        "BooleanVar": LegacyVariable,
        "DoubleVar": LegacyVariable,
        "IntVar": LegacyVariable,
        "Variable": LegacyVariable,
        "TclError": RuntimeError,
        "END": "end",
        "INSERT": "insert",
        "BOTH": "both",
        "X": "x",
        "Y": "y",
        "LEFT": "left",
        "RIGHT": "right",
        "TOP": "top",
        "BOTTOM": "bottom",
        "CENTER": "center",
        "W": "w",
        "E": "e",
        "N": "n",
        "S": "s",
        "HORIZONTAL": "horizontal",
        "VERTICAL": "vertical",
        "NORMAL": "normal",
        "DISABLED": "disabled",
        "WORD": "word",
    }
    for name, value in names.items():
        setattr(tk_module, name, value)
    tk_module.ttk = ttk_module
    tk_module.messagebox = messagebox_module
    tk_module.filedialog = filedialog_module
    tk_module.simpledialog = simpledialog_module
    tk_module.call = lambda *_args, **_kwargs: None

    ttk_names = {
        "Frame": QtFrame,
        "Label": QtLabel,
        "Button": QtButton,
        "Entry": QtEntry,
        "Combobox": QtComboBox,
        "Treeview": QtTreeview,
        "Scrollbar": QtScrollbar,
        "Style": QtStyle,
        "Spinbox": QtSpinbox,
        "Separator": QtSeparator,
        "Progressbar": QtProgressbar,
        "Notebook": QtNotebook,
    }
    for name, value in ttk_names.items():
        setattr(ttk_module, name, value)

    for name, value in vars(_MessageBox).items():
        if not name.startswith("_"):
            setattr(messagebox_module, name, value)
    for name, value in vars(_FileDialog).items():
        if not name.startswith("_"):
            setattr(filedialog_module, name, value)
    for name, value in vars(_SimpleDialog).items():
        if not name.startswith("_"):
            setattr(simpledialog_module, name, value)

    tb_module = types.ModuleType("ttkbootstrap")
    tb_module.Window = QtWidgets.QMainWindow
    tb_module.Frame = QtFrame
    tb_module.Label = QtLabel
    tb_module.Button = QtButton
    tb_module.Entry = QtEntry
    tb_module.Style = QtStyle
    ctk_module = types.ModuleType("customtkinter")
    ctk_module.CTkFrame = QtFrame
    ctk_module.CTkLabel = QtLabel
    ctk_module.CTkButton = QtButton
    ctk_module.CTkEntry = QtEntry
    ctk_module.CTkFont = QtGui.QFont
    ctk_module.CTk = QtWidgets.QMainWindow

    constant_values = {
        "BOTH": "both", "X": "x", "Y": "y", "LEFT": "left", "RIGHT": "right",
        "TOP": "top", "BOTTOM": "bottom", "CENTER": "center", "W": "w", "E": "e",
        "N": "n", "S": "s", "HORIZONTAL": "horizontal", "VERTICAL": "vertical",
    }
    for name, value in constant_values.items():
        setattr(constants_module, name, value)
        setattr(tb_module, name, value)

    sys.modules.update({
        "tkinter": tk_module,
        "tkinter.ttk": ttk_module,
        "tkinter.messagebox": messagebox_module,
        "tkinter.filedialog": filedialog_module,
        "tkinter.simpledialog": simpledialog_module,
        "ttkbootstrap": tb_module,
        "ttkbootstrap.constants": constants_module,
        "customtkinter": ctk_module,
    })


tk = types.SimpleNamespace(**{name: getattr(QtWidgets, name, None) for name in ()})
ttk = types.SimpleNamespace()
messagebox = _MessageBox
filedialog = _FileDialog
simpledialog = _SimpleDialog
