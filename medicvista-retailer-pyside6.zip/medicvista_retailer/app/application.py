from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from PySide6 import QtCore, QtGui, QtWidgets

from .config import load_config
from .db import Database
from .qt_compat import LegacyMixin, LegacyVariable, ensure_application
from .sync import SyncService


_LOG = logging.getLogger(__name__)


class _TimerScheduler(QtCore.QObject):
    requested = QtCore.Signal(str, int, object)
    cancelled = QtCore.Signal(str)

    def __init__(self, parent: QtCore.QObject):
        super().__init__(parent)
        self._active: dict[str, QtCore.QTimer] = {}
        self.requested.connect(self._start, QtCore.Qt.ConnectionType.QueuedConnection)
        self.cancelled.connect(self._cancel, QtCore.Qt.ConnectionType.QueuedConnection)

    @QtCore.Slot(str, int, object)
    def _start(self, token: str, milliseconds: int, callback: Callable) -> None:
        timer = QtCore.QTimer(self)
        timer.setSingleShot(True)
        timer.timeout.connect(callback)
        timer.timeout.connect(lambda: self._active.pop(token, None))
        self._active[token] = timer
        timer.start(max(0, milliseconds))

    @QtCore.Slot(str)
    def _cancel(self, token: str) -> None:
        timer = self._active.pop(token, None)
        if timer:
            timer.stop()
            timer.deleteLater()


try:
    from retailer_sync_bridge import SyncBridge
    from retailer_sync_runner import _load_config as _load_sync_config

    _SYNC_AVAILABLE = True
except Exception:
    _SYNC_AVAILABLE = False


class RetailerDesktopApp(LegacyMixin, QtWidgets.QMainWindow):
    """Native PySide6 application shell hosting the converted retailer screens."""

    sync_update = QtCore.Signal(object)

    _SCREEN_IMPORTS = (
        ("Dashboard", "app.ui.dashboard_screen", "DashboardScreen"),
        ("Purchase Challan", "app.ui.challan.challan_screen", "ChallanScreen"),
        ("New Invoice", "app.ui.purchase.purchase_screen", "PurchaseScreen"),
        ("Invoices", "app.ui.purchase.purchase_screen", "PurchaseScreen"),
        ("Reorder Level", "app.ui.purchase.reorder_level_screen", "ReorderLevelScreen"),
        ("Suppliers", "app.ui.supplier.supplier_screen", "SupplierScreen"),
        ("Returns", "app.ui.returns.returns_screen", "ReturnsScreen"),
        ("Payment", "app.ui.receipts.receipts_screen", "ReceiptsScreen"),
        ("Sales Challan", "app.ui.challan.challan_screen", "ChallanScreen"),
        ("Sales New Invoice", "app.ui.sales.sales_screen", "SalesScreen"),
        ("Sales Invoices", "app.ui.sales.sales_screen", "SalesScreen"),
        ("Customers", "app.ui.customer.customer_screen", "CustomerScreen"),
        ("Receipt", "app.ui.receipts.receipts_screen", "ReceiptsScreen"),
        ("Stock Issues", "app.ui.stock_issue.stock_issue_screen", "StockIssueScreen"),
        ("Product List", "app.ui.product.product_screen", "ProductScreen"),
        ("All Products Inventory", "app.ui.inventory.inventory_screen", "InventoryScreen"),
        ("Batch-wise Report", "app.ui.inventory.batch_wise_screen", "BatchWiseScreen"),
        ("Date-wise Report", "app.ui.inventory.date_wise_screen", "DateWiseScreen"),
        ("Stock Statement", "app.ui.inventory.stock_statement_screen", "StockStatementScreen"),
        ("Transaction History", "app.ui.inventory.transaction_history_screen", "TransactionHistoryScreen"),
        ("Sales Report", "app.ui.reports.reports_screen", "ReportsScreen"),
        ("Customer Wise Sales", "app.ui.reports.reports_screen", "ReportsScreen"),
        ("Purchases Report", "app.ui.reports.reports_screen", "ReportsScreen"),
        ("Reports", "app.ui.reports.reports_screen", "ReportsScreen"),
        ("Financial Report", "app.ui.reports.financial_report_screen", "FinancialReportScreen"),
        ("Ledger", "app.ui.ledger.ledger_screen", "LedgerScreen"),
        ("Retailer Requests", "app.ui.retailer_requests.retailer_requests_screen", "RetailerRequestsScreen"),
        ("Database Backup", "app.ui.system.backup_screen", "BackupScreen"),
    )

    _NAV_GROUPS = (
        ("Home", (("Dashboard", "⌂"),)),
        ("Purchases", (
            ("Purchase Challan", "▤"), ("New Invoice", "+"), ("Invoices", "▣"),
            ("Reorder Level", "↗"), ("Suppliers", "♙"), ("Purchase Return", "↩"),
            ("Payment", "₹"),
        )),
        ("Sales", (
            ("Sales Challan", "▤"), ("Sales New Invoice", "+"), ("Sales Invoices", "▣"),
            ("Customers", "♙"), ("Receipt", "₹"), ("Sales Return", "↩"),
            ("Stock Issues", "−"),
        )),
        ("Inventory", (
            ("Product List", "▦"), ("All Products Inventory", "▤"),
            ("Batch-wise Report", "≡"), ("Date-wise Report", "◷"),
            ("Stock Statement", "▧"), ("Transaction History", "↔"),
        )),
        ("Reports", (
            ("Sales Report", "▥"), ("Customer Wise Sales", "▥"),
            ("Purchases Report", "▥"), ("Reports", "▤"),
            ("Financial Report", "₹"), ("Ledger", "≡"),
        )),
        ("Operations", (("Retailer Requests", "✉"), ("Database Backup", "⤓"))),
    )

    def __init__(self) -> None:
        ensure_application()
        super().__init__()
        self._legacy_init(None, {})
        self.setWindowTitle("MedicVista Retailer")
        self.resize(1440, 900)
        self.setMinimumSize(1050, 680)
        self.setStyleSheet(self._app_stylesheet())

        self._base_config = load_config()
        self._current_user = ""
        self._current_retailer_name = ""
        self._active_screen: QtWidgets.QWidget | None = None
        self.screens: dict[str, QtWidgets.QWidget] = {}
        self._screen_errors: dict[str, str] = {}
        self._shortcuts: list[QtGui.QShortcut] = []
        self._timers: dict[str, QtCore.QTimer] = {}
        self._timer_scheduler = _TimerScheduler(self)
        self._timer_counter = 0
        self._main_built = False
        self.last_sync_at = None
        self.current_fy_start = None
        self.current_fy_end = None
        self._conn_var = LegacyVariable("● Connection: checking…")
        self._sync_var = LegacyVariable("Last sync: never")
        self._login_frame: QtWidgets.QWidget | None = None
        self.sync_update.connect(self._on_wholesaler_sync)
        self._show_login()

    @staticmethod
    def _app_stylesheet() -> str:
        return """
            QMainWindow, QWidget { background: #f4f6fb; color: #18223b; font-family: "Segoe UI", sans-serif; }
            QFrame#topbar { background: #101a2d; }
            QFrame#sidebar { background: #152238; }
            QFrame#statusbar { background: #101a2d; }
            QLabel#brand { color: #ffffff; font-size: 17px; font-weight: 700; }
            QLabel#sectionLabel { color: #8090a8; font-size: 10px; font-weight: 700; padding: 14px 14px 5px; }
            QPushButton#navButton { text-align: left; color: #cbd5e1; background: transparent; border: 0; border-radius: 7px; padding: 9px 12px; }
            QPushButton#navButton:hover { color: white; background: #253752; }
            QPushButton#navButton[active="true"] { color: white; background: #4f46e5; font-weight: 700; }
            QPushButton#topButton { color: #e2e8f0; background: #1e2d45; border: 0; border-radius: 6px; padding: 7px 11px; }
            QPushButton#topButton:hover { background: #334761; }
            QComboBox#fyCombo { color: #e2e8f0; background: #1e2d45; border: 0; border-radius: 6px; padding: 6px 9px; }
            QFrame#contentSurface { background: #f4f6fb; }
            QLabel#statusText { color: #9aa8bc; font-size: 11px; }
            QTreeWidget, QTableWidget { background: white; alternate-background-color: #f8fafc; border: 1px solid #e4e9f2; border-radius: 7px; }
            QHeaderView::section { background: #f1f4f9; color: #475569; padding: 8px; border: 0; border-bottom: 1px solid #dce3ed; font-weight: 600; }
            QLineEdit, QComboBox, QSpinBox, QDateEdit { background: white; border: 1px solid #d8dfeb; border-radius: 5px; padding: 6px 8px; selection-background-color: #635bff; }
            QPushButton { background: #635bff; color: white; border: 0; border-radius: 5px; padding: 7px 12px; }
            QPushButton:hover { background: #5148e8; }
            QScrollBar:vertical { background: transparent; width: 11px; margin: 0; }
            QScrollBar::handle:vertical { background: #c4ccda; border-radius: 5px; min-height: 28px; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
        """

    def _show_login(self) -> None:
        from .ui.login.modern_login_screen import ModernLoginScreen

        self._login_frame = ModernLoginScreen(self, app_instance=self, on_login=self._on_login_success)
        self.setCentralWidget(self._login_frame)
        self.show()

    def _on_login_success(self, username: str, password: str, retailer_id: int, full_name: str) -> None:
        """Called by the login screen after the retailer account is authenticated."""
        from dataclasses import replace

        store_name = (full_name or username or f"Store {retailer_id}").strip()
        retailer_code = self._base_config.retailer_code or f"RTL{retailer_id:03d}"
        self._current_user = username
        self._current_retailer_name = store_name
        self.config_data = replace(
            self._base_config,
            retailer_id=int(retailer_id),
            store_name=store_name,
            retailer_code=retailer_code,
        )
        self.db = Database(self.config_data)
        if self._login_frame:
            self._login_frame.deleteLater()
            self._login_frame = None

        self._build_shell()
        self.sync_service = SyncService(self, self.db, self.config_data.poll_seconds)
        self._main_built = True
        self.sync_bridge = self._create_sync_bridge(retailer_id)
        self._register_screens()
        if self.sync_bridge:
            self.sync_bridge.start()
        self.show_screen("Invoices")
        self.after(500, self.sync_service.start)
        self._install_shortcuts()

    def _create_sync_bridge(self, retailer_id: int) -> Any:
        if not _SYNC_AVAILABLE:
            return None
        try:
            from retailer_sync_runner import get_retailer_config

            sync_config = get_retailer_config(_load_sync_config(), retailer_id)
            if (
                not sync_config.get("api_key")
                or sync_config["api_key"] == "WILL_BE_SET_ON_LOGIN"
                or not sync_config.get("retailer_id")
            ):
                return None
            bridge = SyncBridge(self, sync_config, app_db=self.db)
            bridge.on_update = lambda result: self.sync_update.emit(result)
            if getattr(bridge, "_runner", None):
                bridge._runner._tk_root = self
            return bridge
        except Exception:
            _LOG.exception("Retailer sync could not be configured; local functions remain available.")
            return None

    def _build_shell(self) -> None:
        shell = QtWidgets.QWidget()
        root = QtWidgets.QVBoxLayout(shell)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        topbar = QtWidgets.QFrame()
        topbar.setObjectName("topbar")
        topbar.setFixedHeight(58)
        top_layout = QtWidgets.QHBoxLayout(topbar)
        top_layout.setContentsMargins(18, 0, 18, 0)
        brand = QtWidgets.QLabel("✦  MedicVista Retailer")
        brand.setObjectName("brand")
        top_layout.addWidget(brand)
        top_layout.addStretch(1)

        self.fy_combo = QtWidgets.QComboBox()
        self.fy_combo.setObjectName("fyCombo")
        self.fy_combo.addItems(self._financial_years())
        self.fy_combo.setCurrentText(self._current_financial_year())
        self.fy_combo.currentTextChanged.connect(lambda _value: self._on_fy_change())
        top_layout.addWidget(self.fy_combo)
        self.fy_var = LegacyVariable(self.fy_combo.currentText())

        self._user_button = QtWidgets.QPushButton(f"♙  {self._current_user}")
        self._user_button.setObjectName("topButton")
        top_layout.addWidget(self._user_button)
        logout = QtWidgets.QPushButton("Sign out")
        logout.setObjectName("topButton")
        logout.clicked.connect(self._do_logout)
        top_layout.addWidget(logout)
        help_button = QtWidgets.QPushButton("Keyboard shortcuts")
        help_button.setObjectName("topButton")
        help_button.clicked.connect(self._show_shortcuts)
        top_layout.addWidget(help_button)
        root.addWidget(topbar)

        body = QtWidgets.QWidget()
        body_layout = QtWidgets.QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        self.sidebar = QtWidgets.QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setMinimumWidth(224)
        self.sidebar.setMaximumWidth(224)
        sidebar_outer = QtWidgets.QVBoxLayout(self.sidebar)
        sidebar_outer.setContentsMargins(10, 14, 10, 14)
        sidebar_scroll = QtWidgets.QScrollArea()
        sidebar_scroll.setWidgetResizable(True)
        sidebar_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        sidebar_scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: #152238; border: 0; }")
        sidebar_inner = QtWidgets.QWidget()
        sidebar_layout = QtWidgets.QVBoxLayout(sidebar_inner)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(2)
        self._nav_buttons: dict[str, QtWidgets.QPushButton] = {}
        for group, items in self._NAV_GROUPS:
            section = QtWidgets.QLabel(group.upper())
            section.setObjectName("sectionLabel")
            sidebar_layout.addWidget(section)
            for label, icon in items:
                button = QtWidgets.QPushButton(f"{icon}   {label}")
                button.setObjectName("navButton")
                button.clicked.connect(lambda _checked=False, screen=label: self.show_screen(screen))
                sidebar_layout.addWidget(button)
                self._nav_buttons[label] = button
        sidebar_layout.addStretch(1)
        sidebar_scroll.setWidget(sidebar_inner)
        sidebar_outer.addWidget(sidebar_scroll)
        body_layout.addWidget(self.sidebar)

        separator = QtWidgets.QFrame()
        separator.setFixedWidth(1)
        separator.setStyleSheet("background: #dfe5ee;")
        body_layout.addWidget(separator)

        self.content_area = QtWidgets.QWidget()
        self.content_area.setObjectName("contentSurface")
        self.content_layout = QtWidgets.QVBoxLayout(self.content_area)
        self.content_layout.setContentsMargins(18, 16, 18, 16)
        self.content_layout.setSpacing(0)
        body_layout.addWidget(self.content_area, 1)
        root.addWidget(body, 1)

        status = QtWidgets.QFrame()
        status.setObjectName("statusbar")
        status.setFixedHeight(31)
        status_layout = QtWidgets.QHBoxLayout(status)
        status_layout.setContentsMargins(14, 0, 14, 0)
        self._connection_label = QtWidgets.QLabel()
        self._connection_label.setObjectName("statusText")
        self._sync_label = QtWidgets.QLabel()
        self._sync_label.setObjectName("statusText")
        self._version_label = QtWidgets.QLabel("MedicVista Retailer · PySide6")
        self._version_label.setObjectName("statusText")
        self._conn_var.subscribe(self._connection_label.setText)
        self._sync_var.subscribe(self._sync_label.setText)
        self._connection_label.setText(str(self._conn_var.get()))
        self._sync_label.setText(str(self._sync_var.get()))
        status_layout.addWidget(self._connection_label)
        status_layout.addSpacing(18)
        status_layout.addWidget(self._sync_label)
        status_layout.addStretch(1)
        status_layout.addWidget(self._version_label)
        root.addWidget(status)
        self.setCentralWidget(shell)

    @staticmethod
    def _current_financial_year() -> str:
        now = datetime.now()
        return f"{now.year}-{now.year + 1}" if now.month >= 4 else f"{now.year - 1}-{now.year}"

    @staticmethod
    def _financial_years() -> list[str]:
        now = datetime.now()
        end_year = now.year + (3 if now.month >= 4 else 2)
        return [f"{year}-{year + 1}" for year in range(end_year - 1, 2011, -1)]

    def _on_fy_change(self) -> None:
        selected = self.fy_combo.currentText()
        self.fy_var.set(selected)
        if "-" in selected:
            start_year, end_year = selected.split("-", 1)
            self.current_fy_start = f"{start_year}-04-01"
            self.current_fy_end = f"{end_year}-03-31"
        screen = self._active_screen
        if screen and hasattr(screen, "fy_var") and hasattr(screen, "refresh_data"):
            screen.fy_var.set(selected)
            if hasattr(screen, "_set_current_fy_dates"):
                screen._set_current_fy_dates()
            screen.refresh_data()
        elif screen and hasattr(screen, "on_show"):
            try:
                screen.on_show()
            except Exception:
                _LOG.exception("Could not refresh the current screen after changing financial year.")

    def _register_screens(self) -> None:
        import importlib

        for name, module_name, class_name in self._SCREEN_IMPORTS:
            if name in self.screens:
                continue
            try:
                screen_class = getattr(importlib.import_module(module_name), class_name)
                screen = screen_class(self.content_area, self)
                if screen.parentWidget() is None:
                    screen.setParent(self.content_area)
                if self.content_layout.indexOf(screen) < 0:
                    self.content_layout.addWidget(screen)
                screen.hide()
                self.screens[name] = screen
            except Exception as exc:
                _LOG.exception("Screen initialization failed for %s.", name)
                self._screen_errors[name] = str(exc)
                fallback = QtWidgets.QFrame(self.content_area)
                fallback_layout = QtWidgets.QVBoxLayout(fallback)
                fallback_layout.addStretch(1)
                message = QtWidgets.QLabel(f"{name} could not be opened.\n{exc}")
                message.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
                message.setWordWrap(True)
                fallback_layout.addWidget(message)
                fallback_layout.addStretch(1)
                self.content_layout.addWidget(fallback)
                fallback.hide()
                self.screens[name] = fallback

    def show_screen(self, name: str) -> None:
        if name == "New Invoice":
            self._open_invoice_dialog("purchase")
            return
        if name == "Sales New Invoice":
            self._open_invoice_dialog("sales")
            return
        mode = "purchase" if name == "Purchase Return" else "sales" if name == "Sales Return" else None
        aliases = {"Sales": "Sales Report", "Purchases": "Purchases Report"}
        name = aliases.get(name, name)
        screen_key = "Returns" if mode else name
        for screen in self.screens.values():
            screen.hide()
        screen = self.screens.get(screen_key)
        if screen is None:
            return
        if mode and hasattr(screen, "_switch"):
            screen._switch(mode)
        if hasattr(screen, "set_screen_name"):
            screen.set_screen_name(name)
        screen.show()
        self._active_screen = screen
        for label, button in self._nav_buttons.items():
            button.setProperty("active", label == name or (label == "Returns" and mode is not None))
            button.style().unpolish(button)
            button.style().polish(button)
        if hasattr(screen, "on_show"):
            try:
                screen.on_show()
            except Exception:
                _LOG.exception("Could not refresh screen %s.", name)

    def _open_invoice_dialog(self, kind: str) -> None:
        try:
            if kind == "purchase":
                from .ui.purchase.purchase_invoice_dialog import PurchaseInvoiceDialog

                dialog = PurchaseInvoiceDialog(self.content_area, self, on_saved=self.refresh_invoice_views)
            else:
                from .ui.sales.sales_invoice_dialog import SalesInvoiceDialog

                dialog = SalesInvoiceDialog(self.content_area, self, on_saved=self.refresh_invoice_views)
            if isinstance(dialog, QtWidgets.QDialog):
                dialog.setModal(True)
                dialog.show()
        except Exception:
            _LOG.exception("Could not open the %s invoice dialog.", kind)
            QtWidgets.QMessageBox.critical(self, "Unable to open invoice", "The invoice form could not be opened. See the application log for details.")

    def _install_shortcuts(self) -> None:
        try:
            from .shortcuts import install_shortcuts

            install_shortcuts(self, self)
        except Exception:
            _LOG.exception("Some global keyboard shortcuts could not be registered.")

        self._bind_shortcut("Ctrl+R", self.refresh_current)
        self._bind_shortcut("Ctrl+N", self.kb_new)
        self._bind_shortcut("Ctrl+F", self.kb_search)
        self._bind_shortcut("Ctrl+B", lambda: self.fy_combo.setFocus())
        self._bind_shortcut("F12", self._show_shortcuts)

    def _bind_shortcut(self, sequence: str, callback: Callable) -> None:
        shortcut = QtGui.QShortcut(QtGui.QKeySequence(sequence), self)
        shortcut.activated.connect(callback)
        self._shortcuts.append(shortcut)

    def bind(self, sequence: str, callback: Callable, add: Any = None) -> str:
        return self._create_legacy_shortcut(sequence, callback)

    def bind_all(self, sequence: str, callback: Callable, add: Any = None) -> str:
        return self._create_legacy_shortcut(sequence, callback)

    def _create_legacy_shortcut(self, sequence: str, callback: Callable) -> str:
        from .qt_compat import _sequence_to_key

        key = _sequence_to_key(sequence)
        if key:
            shortcut = QtGui.QShortcut(key, self)
            shortcut.activated.connect(lambda: callback())
            self._shortcuts.append(shortcut)
            return str(id(shortcut))
        return ""

    def after(self, milliseconds: int, callback: Callable) -> str:
        self._timer_counter += 1
        token = f"qt-timer-{self._timer_counter}"
        self._timer_scheduler.requested.emit(token, max(0, int(milliseconds)), callback)
        return token

    def after_cancel(self, token: str) -> None:
        self._timer_scheduler.cancelled.emit(str(token))

    def _active_screen_instance(self) -> QtWidgets.QWidget | None:
        return self._active_screen if self._active_screen and self._active_screen.isVisible() else None

    def kb_new(self) -> None:
        screen = self._active_screen_instance()
        if screen and hasattr(screen, "kb_new"):
            screen.kb_new()

    def kb_search(self) -> None:
        screen = self._active_screen_instance()
        if screen and hasattr(screen, "kb_search"):
            screen.kb_search()

    def kb_refresh(self) -> None:
        screen = self._active_screen_instance()
        if screen and hasattr(screen, "kb_refresh"):
            screen.kb_refresh()
        elif screen and hasattr(screen, "on_show"):
            screen.on_show()

    def refresh_current(self) -> None:
        self.kb_refresh()

    def refresh_invoice_views(self) -> None:
        for screen_name in ("Invoices", "Sales Invoices"):
            screen = self.screens.get(screen_name)
            if screen and hasattr(screen, "on_show"):
                try:
                    screen.on_show()
                except Exception:
                    _LOG.exception("Could not refresh %s.", screen_name)

    def sync_now(self) -> None:
        try:
            self.sync_service.sync_now(schedule_next=False)
        except Exception:
            _LOG.exception("Manual sync failed.")

    def toggle_sidebar(self) -> None:
        self.sidebar.setVisible(not self.sidebar.isVisible())

    def set_connection_status(self, text: str) -> None:
        self._conn_var.set(text)

    def set_sync_status(self, timestamp: Any) -> None:
        formatted = timestamp.strftime("%d-%m-%Y %H:%M") if timestamp else "never"
        self._sync_var.set(f"Last sync: {formatted}")

    def set_status(self, text: str) -> None:
        self._conn_var.set(text)

    def set_connection_state(self, connected: bool, message: str = "") -> None:
        self._conn_var.set("● Connection: OK" if connected else f"● Connection: {message[:60] or 'failed'}")

    def on_sync_complete(self, processed: int) -> None:
        self.set_sync_status(self.last_sync_at)
        self._conn_var.set(f"● Synced {processed} request(s)" if processed else "● Connection: OK")

    def process_request(self, request: dict[str, Any]) -> None:
        """Refresh affected data views after an incoming request has been processed."""
        self.refresh_invoice_views()
        if self._active_screen and hasattr(self._active_screen, "on_show"):
            self._active_screen.on_show()

    def _show_shortcuts(self) -> None:
        try:
            from .shortcuts import show_help

            show_help(self)
        except Exception:
            QtWidgets.QMessageBox.information(self, "Keyboard shortcuts", "Use F1–F12 for navigation and Ctrl+R to refresh the current screen.")

    def _on_wholesaler_sync(self, result: dict[str, Any]) -> None:
        connected = bool(result.get("connected", False))
        new_count = len(result.get("new_requests", []))
        error = result.get("error")
        self._conn_var.set("● Connected to wholesaler" if connected else f"● Wholesaler: {str(error or 'Disconnected')[:50]}")
        if result.get("last_sync_time"):
            self._sync_var.set(f"Last sync: {result['last_sync_time']}")
        screen = self.screens.get("Retailer Requests")
        if screen and hasattr(screen, "_on_sync_result"):
            screen._on_sync_result(result)
        elif screen and hasattr(screen, "on_show"):
            screen.on_show()
        if new_count:
            self._conn_var.set(f"● {new_count} new retailer request(s)")
            self.after(5000, lambda: self._conn_var.set("● Connected to wholesaler" if connected else "● Wholesaler: Disconnected"))

    def _do_logout(self) -> None:
        bridge = getattr(self, "sync_bridge", None)
        if bridge and getattr(bridge, "_runner", None):
            try:
                bridge._runner.on_sync_complete = lambda *args, **kwargs: None
            except Exception:
                pass
        service = getattr(self, "sync_service", None)
        if service:
            service.stop()
        if bridge:
            try:
                bridge.stop()
            except Exception:
                _LOG.exception("Could not stop retailer sync cleanly.")
        for timer in list(self._timers.values()):
            timer.stop()
        self._timers.clear()
        self.screens.clear()
        self._active_screen = None
        self._main_built = False
        self._current_user = ""
        self.sync_bridge = None
        self._show_login()

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        callback = getattr(self, "_legacy_close_callback", None)
        if callback:
            callback()
            event.accept()
            return
        service = getattr(self, "sync_service", None)
        if service:
            service.stop()
        bridge = getattr(self, "sync_bridge", None)
        if bridge:
            try:
                bridge.stop()
            except Exception:
                _LOG.exception("Could not stop retailer sync cleanly.")
        event.accept()
