"""MedicVista retailer desktop application."""
